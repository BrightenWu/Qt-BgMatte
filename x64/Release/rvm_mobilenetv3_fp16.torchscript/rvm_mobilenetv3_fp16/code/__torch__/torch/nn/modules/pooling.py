class AdaptiveAvgPool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : None
  output_size : Final[int] = 1
  def forward(self: __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.adaptive_avg_pool2d
    return _0(input, [1, 1], )
class AvgPool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : None
  divisor_override : Final[None] = None
  stride : Final[int] = 2
  count_include_pad : Final[bool] = False
  kernel_size : Final[int] = 2
  padding : Final[int] = 0
  ceil_mode : Final[bool] = True
  def forward(self: __torch__.torch.nn.modules.pooling.AvgPool2d,
    input: Tensor) -> Tensor:
    _1 = torch.avg_pool2d(input, [2, 2], [2, 2], [0, 0], True, False, None)
    return _1
