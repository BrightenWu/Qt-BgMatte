class LRASPP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  aspp1 : __torch__.torch.nn.modules.container.___torch_mangle_117.Sequential
  aspp2 : __torch__.torch.nn.modules.container.___torch_mangle_118.Sequential
  def forward(self: __torch__.model.lraspp.LRASPP,
    x: Tensor) -> Tensor:
    if torch.eq(torch.dim(x), 5):
      _0 = (self).forward_time_series(x, )
    else:
      _0 = (self).forward_single_frame(x, )
    return _0
  def forward_time_series(self: __torch__.model.lraspp.LRASPP,
    x: Tensor) -> Tensor:
    B, T, = torch.slice(torch.size(x), 0, 2, 1)
    x0 = (self).forward_single_frame(torch.flatten(x, 0, 1), )
    _1 = [B, T, torch.size(x0, 1), torch.size(x0, 2), torch.size(x0, 3)]
    return torch.reshape(x0, _1)
  def forward_single_frame(self: __torch__.model.lraspp.LRASPP,
    x: Tensor) -> Tensor:
    _2 = torch.mul((self.aspp1).forward(x, ), (self.aspp2).forward(x, ))
    return _2
