class MobileNetV3LargeEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_114.Sequential
  def forward(self: __torch__.model.mobilenetv3.MobileNetV3LargeEncoder,
    x: Tensor) -> List[Tensor]:
    if torch.eq(torch.dim(x), 5):
      _0 = (self).forward_time_series(x, )
    else:
      _0 = (self).forward_single_frame(x, )
    return _0
  def forward_time_series(self: __torch__.model.mobilenetv3.MobileNetV3LargeEncoder,
    x: Tensor) -> List[Tensor]:
    B, T, = torch.slice(torch.size(x), 0, 2, 1)
    features = (self).forward_single_frame(torch.flatten(x, 0, 1), )
    features0 = annotate(List[Tensor], [])
    for _1 in range(torch.len(features)):
      f = features[_1]
      _2 = [B, T, torch.size(f, 1), torch.size(f, 2), torch.size(f, 3)]
      _3 = torch.append(features0, torch.reshape(f, _2))
    return features0
  def forward_single_frame(self: __torch__.model.mobilenetv3.MobileNetV3LargeEncoder,
    x: Tensor) -> List[Tensor]:
    _4 = __torch__.torchvision.transforms.functional.normalize
    _5 = [0.48499999999999999, 0.45600000000000002, 0.40600000000000003]
    _6 = [0.22900000000000001, 0.224, 0.22500000000000001]
    x0 = _4(x, _5, _6, False, )
    x1 = (getattr(self.features, "0")).forward(x0, )
    x2 = (getattr(self.features, "1")).forward(x1, )
    x3 = (getattr(self.features, "2")).forward(x2, )
    x4 = (getattr(self.features, "3")).forward(x3, )
    x5 = (getattr(self.features, "4")).forward(x4, )
    x6 = (getattr(self.features, "5")).forward(x5, )
    x7 = (getattr(self.features, "6")).forward(x6, )
    x8 = (getattr(self.features, "7")).forward(x7, )
    x9 = (getattr(self.features, "8")).forward(x8, )
    x10 = (getattr(self.features, "9")).forward(x9, )
    x11 = (getattr(self.features, "10")).forward(x10, )
    x12 = (getattr(self.features, "11")).forward(x11, )
    x13 = (getattr(self.features, "12")).forward(x12, )
    x14 = (getattr(self.features, "13")).forward(x13, )
    x15 = (getattr(self.features, "14")).forward(x14, )
    x16 = (getattr(self.features, "15")).forward(x15, )
    x17 = (getattr(self.features, "16")).forward(x16, )
    return [x2, x4, x7, x17]
