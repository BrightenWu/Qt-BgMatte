class RecurrentDecoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  avgpool : __torch__.model.decoder.AvgPool
  decode4 : __torch__.model.decoder.BottleneckBlock
  decode3 : __torch__.model.decoder.UpsamplingBlock
  decode2 : __torch__.model.decoder.___torch_mangle_139.UpsamplingBlock
  decode1 : __torch__.model.decoder.___torch_mangle_148.UpsamplingBlock
  decode0 : __torch__.model.decoder.OutputBlock
  def forward(self: __torch__.model.decoder.RecurrentDecoder,
    s0: Tensor,
    f1: Tensor,
    f2: Tensor,
    f3: Tensor,
    f4: Tensor,
    r1: Optional[Tensor],
    r2: Optional[Tensor],
    r3: Optional[Tensor],
    r4: Optional[Tensor]) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    s1, s2, s3, = (self.avgpool).forward(s0, )
    x4, r40, = (self.decode4).forward(f4, r4, )
    _0 = (self.decode3).forward(x4, f3, s3, r3, )
    x3, r30, = _0
    _1 = (self.decode2).forward(x3, f2, s2, r2, )
    x2, r20, = _1
    _2 = (self.decode1).forward(x2, f1, s1, r1, )
    x1, r10, = _2
    x0 = (self.decode0).forward(x1, s0, )
    return (x0, r10, r20, r30, r40)
class AvgPool(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  avgpool : __torch__.torch.nn.modules.pooling.AvgPool2d
  def forward(self: __torch__.model.decoder.AvgPool,
    s0: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    if torch.eq(torch.dim(s0), 5):
      _3 = (self).forward_time_series(s0, )
    else:
      _3 = (self).forward_single_frame(s0, )
    return _3
  def forward_time_series(self: __torch__.model.decoder.AvgPool,
    s0: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _4 = torch.slice(torch.size(s0), 0, 2, 1)
    B, T, = _4
    _5 = (self).forward_single_frame(torch.flatten(s0, 0, 1), )
    s1, s2, s3, = _5
    _6 = [B, T, torch.size(s1, 1), torch.size(s1, 2), torch.size(s1, 3)]
    s10 = torch.reshape(s1, _6)
    _7 = [B, T, torch.size(s2, 1), torch.size(s2, 2), torch.size(s2, 3)]
    s20 = torch.reshape(s2, _7)
    _8 = [B, T, torch.size(s3, 1), torch.size(s3, 2), torch.size(s3, 3)]
    s30 = torch.reshape(s3, _8)
    return (s10, s20, s30)
  def forward_single_frame(self: __torch__.model.decoder.AvgPool,
    s0: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    s1 = (self.avgpool).forward(s0, )
    s2 = (self.avgpool).forward(s1, )
    s3 = (self.avgpool).forward(s2, )
    return (s1, s2, s3)
class BottleneckBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  channels : int
  gru : __torch__.model.decoder.ConvGRU
  def forward(self: __torch__.model.decoder.BottleneckBlock,
    x: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    _9 = torch.split(x, torch.floordiv(self.channels, 2), -3)
    a, b, = _9
    b0, r0, = (self.gru).forward(b, r, )
    x0 = torch.cat([a, b0], -3)
    return (x0, r0)
class ConvGRU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  channels : int
  ih : __torch__.torch.nn.modules.container.___torch_mangle_120.Sequential
  hh : __torch__.torch.nn.modules.container.___torch_mangle_122.Sequential
  def forward(self: __torch__.model.decoder.ConvGRU,
    x: Tensor,
    h: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    if torch.__is__(h, None):
      h1 = torch.zeros_like(x, dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
      h0 = h1
    else:
      h0 = unchecked_cast(Tensor, h)
    if torch.eq(torch.dim(x), 5):
      _11 = (self).forward_time_series(x, h0, )
      _10 = _11
    else:
      _12 = (self).forward_single_frame(x, h0, )
      _10 = _12
    return _10
  def forward_time_series(self: __torch__.model.decoder.ConvGRU,
    x: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    o = annotate(List[Tensor], [])
    _13 = torch.unbind(x, 1)
    h2 = h
    for _14 in range(torch.len(_13)):
      xt = _13[_14]
      _15 = (self).forward_single_frame(xt, h2, )
      ot, h3, = _15
      _16 = torch.append(o, ot)
      h2 = h3
    o0 = torch.stack(o, 1)
    return (o0, h2)
  def forward_single_frame(self: __torch__.model.decoder.ConvGRU,
    x: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    _17 = (self.ih).forward(torch.cat([x, h], 1), )
    r, z, = torch.split(_17, self.channels, 1)
    c = (self.hh).forward(torch.cat([x, torch.mul(r, h)], 1), )
    _18 = torch.mul(torch.add(torch.neg(z), 1, 1), h)
    h4 = torch.add(_18, torch.mul(z, c), alpha=1)
    return (h4, h4)
class UpsamplingBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  out_channels : int
  upsample : __torch__.torch.nn.modules.upsampling.Upsample
  conv : __torch__.torch.nn.modules.container.___torch_mangle_125.Sequential
  gru : __torch__.model.decoder.___torch_mangle_130.ConvGRU
  def forward(self: __torch__.model.decoder.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.dim(x), 5):
      _20 = (self).forward_time_series(x, f, s, r, )
      _19 = _20
    else:
      _21 = (self).forward_single_frame(x, f, s, r, )
      _19 = _21
    return _19
  def forward_time_series(self: __torch__.model.decoder.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    B, T, _22, H, W, = torch.size(s)
    x1 = torch.flatten(x, 0, 1)
    f0 = torch.flatten(f, 0, 1)
    s0 = torch.flatten(s, 0, 1)
    x2 = (self.upsample).forward(x1, )
    _23 = torch.slice(x2, 0, 0, 9223372036854775807, 1)
    _24 = torch.slice(_23, 1, 0, 9223372036854775807, 1)
    x3 = torch.slice(torch.slice(_24, 2, 0, H, 1), 3, 0, W, 1)
    x4 = torch.cat([x3, f0, s0], 1)
    x5 = (self.conv).forward(x4, )
    x6 = torch.reshape(x5, [B, T, -1, H, W])
    _25 = torch.floordiv(self.out_channels, 2)
    a, b, = torch.split(x6, _25, 2)
    b1, r1, = (self.gru).forward(b, r, )
    x7 = torch.cat([a, b1], 2)
    return (x7, r1)
  def forward_single_frame(self: __torch__.model.decoder.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    x8 = (self.upsample).forward(x, )
    _26 = torch.slice(x8, 0, 0, 9223372036854775807, 1)
    _27 = torch.slice(_26, 1, 0, 9223372036854775807, 1)
    _28 = torch.slice(_27, 2, 0, torch.size(s, 2), 1)
    x9 = torch.slice(_28, 3, 0, torch.size(s, 3), 1)
    x10 = torch.cat([x9, f, s], 1)
    x11 = (self.conv).forward(x10, )
    _29 = torch.floordiv(self.out_channels, 2)
    a, b, = torch.split(x11, _29, 1)
    b2, r2, = (self.gru).forward(b, r, )
    x12 = torch.cat([a, b2], 1)
    return (x12, r2)
class OutputBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  upsample : __torch__.torch.nn.modules.upsampling.Upsample
  conv : __torch__.torch.nn.modules.container.___torch_mangle_152.Sequential
  def forward(self: __torch__.model.decoder.OutputBlock,
    x: Tensor,
    s: Tensor) -> Tensor:
    if torch.eq(torch.dim(x), 5):
      _31 = (self).forward_time_series(x, s, )
      _30 = _31
    else:
      _32 = (self).forward_single_frame(x, s, )
      _30 = _32
    return _30
  def forward_time_series(self: __torch__.model.decoder.OutputBlock,
    x: Tensor,
    s: Tensor) -> Tensor:
    B, T, _33, H, W, = torch.size(s)
    x13 = torch.flatten(x, 0, 1)
    s1 = torch.flatten(s, 0, 1)
    x14 = (self.upsample).forward(x13, )
    _34 = torch.slice(x14, 0, 0, 9223372036854775807, 1)
    _35 = torch.slice(_34, 1, 0, 9223372036854775807, 1)
    x15 = torch.slice(torch.slice(_35, 2, 0, H, 1), 3, 0, W, 1)
    x16 = torch.cat([x15, s1], 1)
    x17 = (self.conv).forward(x16, )
    x18 = torch.reshape(x17, [B, T, -1, H, W])
    return x18
  def forward_single_frame(self: __torch__.model.decoder.OutputBlock,
    x: Tensor,
    s: Tensor) -> Tensor:
    x19 = (self.upsample).forward(x, )
    _36 = torch.slice(x19, 0, 0, 9223372036854775807, 1)
    _37 = torch.slice(_36, 1, 0, 9223372036854775807, 1)
    _38 = torch.slice(_37, 2, 0, torch.size(s, 2), 1)
    x20 = torch.slice(_38, 3, 0, torch.size(s, 3), 1)
    x21 = torch.cat([x20, s], 1)
    return (self.conv).forward(x21, )
class Projection(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_153.Conv2d
  def forward(self: __torch__.model.decoder.Projection,
    x: Tensor) -> Tensor:
    if torch.eq(torch.dim(x), 5):
      _39 = (self).forward_time_series(x, )
    else:
      _39 = (self).forward_single_frame(x, )
    return _39
  def forward_time_series(self: __torch__.model.decoder.Projection,
    x: Tensor) -> Tensor:
    B, T, _40, H, W, = torch.size(x)
    _41 = (self.conv).forward(torch.flatten(x, 0, 1), )
    _42 = torch.reshape(_41, [B, T, -1, H, W])
    return _42
  def forward_single_frame(self: __torch__.model.decoder.Projection,
    x: Tensor) -> Tensor:
    return (self.conv).forward(x, )
