class ConvGRU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  channels : int
  ih : __torch__.torch.nn.modules.container.___torch_mangle_144.Sequential
  hh : __torch__.torch.nn.modules.container.___torch_mangle_146.Sequential
  def forward(self: __torch__.model.decoder.___torch_mangle_147.ConvGRU,
    x: Tensor,
    h: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    if torch.__is__(h, None):
      h1 = torch.zeros_like(x, dtype=None, layout=None, device=None, pin_memory=None, memory_format=None)
      h0 = h1
    else:
      h0 = unchecked_cast(Tensor, h)
    if torch.eq(torch.dim(x), 5):
      _1 = (self).forward_time_series(x, h0, )
      _0 = _1
    else:
      _2 = (self).forward_single_frame(x, h0, )
      _0 = _2
    return _0
  def forward_time_series(self: __torch__.model.decoder.___torch_mangle_147.ConvGRU,
    x: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    o = annotate(List[Tensor], [])
    _3 = torch.unbind(x, 1)
    h2 = h
    for _4 in range(torch.len(_3)):
      xt = _3[_4]
      _5 = (self).forward_single_frame(xt, h2, )
      ot, h3, = _5
      _6 = torch.append(o, ot)
      h2 = h3
    o0 = torch.stack(o, 1)
    return (o0, h2)
  def forward_single_frame(self: __torch__.model.decoder.___torch_mangle_147.ConvGRU,
    x: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    _7 = (self.ih).forward(torch.cat([x, h], 1), )
    r, z, = torch.split(_7, self.channels, 1)
    c = (self.hh).forward(torch.cat([x, torch.mul(r, h)], 1), )
    _8 = torch.mul(torch.add(torch.neg(z), 1, 1), h)
    h4 = torch.add(_8, torch.mul(z, c), alpha=1)
    return (h4, h4)
