class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  use_res_connect : bool
  out_channels : int
  _is_cn : bool
  block : __torch__.torch.nn.modules.container.___torch_mangle_21.Sequential
  def forward(self: __torch__.torchvision.models.mobilenetv3.___torch_mangle_22.InvertedResidual,
    input: Tensor) -> Tensor:
    result = (self.block).forward(input, )
    if self.use_res_connect:
      result1 = torch.add_(result, input, alpha=1)
      result0 = result1
    else:
      result0 = result
    return result0
