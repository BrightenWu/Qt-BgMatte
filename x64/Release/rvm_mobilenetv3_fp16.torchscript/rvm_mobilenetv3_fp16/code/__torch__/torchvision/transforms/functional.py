def normalize(tensor: Tensor,
    mean: List[float],
    std: List[float],
    inplace: bool=False) -> Tensor:
  _0 = "Expected tensor to be a tensor image of size (..., C, H, W). Got tensor.size() = {}."
  _1 = "std evaluated to zero after conversion to {}, leading to division by zero."
  tensor0 = unchecked_cast(Tensor, tensor)
  if torch.lt(torch.dim(tensor0), 3):
    _2 = torch.format(_0, torch.size(tensor0))
    ops.prim.RaiseException(_2)
  else:
    pass
  if torch.__not__(inplace):
    tensor2 = torch.clone(tensor0, memory_format=None)
    tensor1 = tensor2
  else:
    tensor1 = tensor0
  dtype = ops.prim.dtype(tensor1)
  mean0 = torch.as_tensor(mean, dtype=dtype, device=ops.prim.device(tensor1))
  std0 = torch.as_tensor(std, dtype=dtype, device=ops.prim.device(tensor1))
  if bool(torch.any(torch.eq(std0, 0))):
    ops.prim.RaiseException(torch.format(_1, dtype))
  else:
    pass
  if torch.eq(torch.dim(mean0), 1):
    mean1 = torch.view(mean0, [-1, 1, 1])
  else:
    mean1 = mean0
  if torch.eq(torch.dim(std0), 1):
    std1 = torch.view(std0, [-1, 1, 1])
  else:
    std1 = std0
  _3 = torch.div_(torch.sub_(tensor1, mean1, alpha=1), std1)
  return tensor1
